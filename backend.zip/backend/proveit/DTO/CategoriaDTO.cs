﻿namespace proveit.DTO
{
    public class CategoriaDTO
    {
        public int Categoria_id { get; set; }
        public string Nome { get; set; }
    }
}
